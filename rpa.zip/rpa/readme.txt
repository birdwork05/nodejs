
install dependencies
$ npm i

start line bot
$ npm run dev

push multicast
$ npm run test

run ngrok
$ ./ngrok http 3005
